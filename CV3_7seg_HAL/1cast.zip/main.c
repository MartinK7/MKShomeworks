
#include "stm32f429xx.h"
#include "max7219.h"
#include "delay.h"

volatile static uint32_t Tick = 0, LEDTick = 0;

void show(uint32_t value) {
	value %= 10000;
	uint32_t a = value / 1000;
	value -= a * 1000;
	uint32_t b = value / 100;
	value -= b * 100;
	uint32_t c = value / 10;
	value -= c * 10;
	uint32_t d = value;

	max7219_led(
			max7219_customRegValues[a] << 24 |
			max7219_customRegValues[b] << 16 |
			max7219_customRegValues[c] << 8 |
			max7219_customRegValues[d]);
}

int main() {
	SystemInit();
	SystemCoreClockUpdate();

	max7219_init(0); // Init, do not use internal decode table

	while(1) {
		static uint32_t i = 0;
		show(i);
		i += 111;
		if(i > 1000)
			i = 0;
		delay_ms(250);
	}
}
